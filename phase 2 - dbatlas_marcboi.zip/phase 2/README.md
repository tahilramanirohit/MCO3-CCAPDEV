# CCAPDEV MCO2 

## Description

A requirement for the CCAPDEV course. This project includes the viewing features of the web application.

### Prerequisites

List any prerequisites needed to run the project. This might include:

- MongoDB Compass

### Initializing the database

For this project, we used MongoDB Compass to store our data, so it is ran locally. A

To get our connection from MongoDB Compass, we will export our connection and send it and you will import the connection using MongoDB Compass

### Running the project

In order to run the project, open the command prompt and input: "node server.js" or "npm start" from the directory of the phase2 folder

After that, access the project using any web broswer with: "localhost:3000"